public class VentanaCalculadora {
    
    public static void main(String[] args) {
        // TODO code application logic here
        interfaz_tabla_multiplicar multiplicar = new interfaz_tabla_multiplicar();
       
        multiplicar.setVisible(true);
   }


}
